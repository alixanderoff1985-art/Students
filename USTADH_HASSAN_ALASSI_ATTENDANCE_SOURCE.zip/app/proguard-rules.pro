# Keep the app unobfuscated for reliable diagnostics and WebView/server operation.
