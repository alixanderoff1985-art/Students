package com.baniyas.stafftracker;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.graphics.Color;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Main screen and lifecycle owner for the local attendance server. */
public class MainActivity extends Activity {
    private static final String LOCAL_URL = "http://127.0.0.1:8080/admin";

    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private final ExecutorService serverExecutor = Executors.newSingleThreadExecutor();
    private volatile boolean activityDestroyed = false;
    private volatile boolean serverReady = false;

    private AttendanceServer server;
    private WebView web;
    private TextView status;
    private ProgressBar progress;
    private Button retryButton;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        buildScreen();
        startServerAsync();
    }

    private void buildScreen() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(245, 248, 247));

        status = new TextView(this);
        status.setText("جارٍ تشغيل خادم المتابعة...");
        status.setTextColor(Color.rgb(20, 80, 64));
        status.setTextSize(16);
        status.setGravity(Gravity.CENTER);
        status.setPadding(16, 18, 16, 18);
        root.addView(status, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        progress = new ProgressBar(this);
        progress.setIndeterminate(true);
        root.addView(progress, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        retryButton = new Button(this);
        retryButton.setText("إعادة المحاولة");
        retryButton.setVisibility(View.GONE);
        retryButton.setOnClickListener(v -> {
            retryButton.setVisibility(View.GONE);
            progress.setVisibility(View.VISIBLE);
            status.setText("جارٍ إعادة الاتصال بالخادم...");
            if (serverReady && web != null) {
                web.loadUrl(LOCAL_URL);
            } else {
                startServerAsync();
            }
        });
        root.addView(retryButton, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        web = new WebView(this);
        WebSettings settings = web.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setLoadsImagesAutomatically(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        web.setWebChromeClient(new WebChromeClient());
        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                progress.setVisibility(View.VISIBLE);
                retryButton.setVisibility(View.GONE);
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                progress.setVisibility(View.GONE);
                status.setText("الخادم يعمل · صفحة الإدارة جاهزة · المنفذ 8080");
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) showLoadError();
            }

            @SuppressWarnings("deprecation")
            @Override
            public void onReceivedError(WebView view, int errorCode, String description, String failingUrl) {
                if (android.os.Build.VERSION.SDK_INT < 23) showLoadError();
            }
        });
        root.addView(web, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1));
        setContentView(root);
    }

    private void startServerAsync() {
        if (serverReady) {
            if (web != null) web.loadUrl(LOCAL_URL);
            return;
        }
        status.setText("جارٍ تهيئة خادم الحضور المحلي...");
        progress.setVisibility(View.VISIBLE);
        retryButton.setVisibility(View.GONE);

        serverExecutor.execute(() -> {
            try {
                if (server == null) {
                    AttendanceServer candidate = new AttendanceServer(getApplicationContext());
                    candidate.start(10000, false);
                    server = candidate;
                }
                serverReady = true;
                mainHandler.post(() -> {
                    if (!activityDestroyed && web != null) {
                        status.setText("الخادم يعمل · جارٍ فتح لوحة الإدارة...");
                        web.loadUrl(LOCAL_URL);
                    }
                });
            } catch (Exception e) {
                final String message = e.getMessage() == null ? "تعذر بدء الخادم" : e.getMessage();
                mainHandler.post(() -> {
                    if (!activityDestroyed) {
                        progress.setVisibility(View.GONE);
                        status.setText("فشل تشغيل الخادم: " + message);
                        retryButton.setVisibility(View.VISIBLE);
                    }
                });
            }
        });
    }

    private void showLoadError() {
        progress.setVisibility(View.GONE);
        status.setText("تعذر تحميل لوحة الإدارة. تحقق من تشغيل الخادم ثم أعد المحاولة.");
        retryButton.setVisibility(View.VISIBLE);
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        activityDestroyed = true;
        if (web != null) {
            web.stopLoading();
            web.loadUrl("about:blank");
            web.removeAllViews();
            web.destroy();
            web = null;
        }
        serverExecutor.execute(() -> {
            if (server != null) {
                server.stop();
                server = null;
                serverReady = false;
            }
        });
        serverExecutor.shutdown();
        super.onDestroy();
    }
}
