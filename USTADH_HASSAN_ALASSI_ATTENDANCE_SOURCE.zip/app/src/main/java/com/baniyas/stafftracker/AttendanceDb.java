package com.baniyas.stafftracker;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import org.json.JSONArray;
import org.json.JSONObject;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/** Local-only attendance database. Student numbers are unique and attendance is unique per lecture. */
public class AttendanceDb extends SQLiteOpenHelper {
    public AttendanceDb(Context c) { super(c, "alhassan_attendance.db", null, 3); }
    @Override public void onCreate(SQLiteDatabase db) { create(db); }
    private void create(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS students(id INTEGER PRIMARY KEY AUTOINCREMENT, student_no TEXT NOT NULL UNIQUE, name TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending', created_at TEXT NOT NULL)");
        db.execSQL("CREATE TABLE IF NOT EXISTS lectures(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, created_at TEXT NOT NULL, active INTEGER NOT NULL DEFAULT 1)");
        db.execSQL("CREATE TABLE IF NOT EXISTS attendance(id INTEGER PRIMARY KEY AUTOINCREMENT, lecture_id INTEGER NOT NULL, student_id INTEGER NOT NULL, scanned_at TEXT NOT NULL, UNIQUE(lecture_id,student_id), FOREIGN KEY(lecture_id) REFERENCES lectures(id), FOREIGN KEY(student_id) REFERENCES students(id))");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_att_lecture ON attendance(lecture_id,scanned_at)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_students_status ON students(status)");
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldV,int newV) { create(db); }
    private String now(){return new SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US).format(new Date());}
    private String clean(String s){return s==null?"":s.trim().replaceAll("\\s+"," ");}
    public synchronized JSONObject requestStudent(String number,String name)throws Exception{
        number=clean(number).toUpperCase(Locale.ROOT); name=clean(name);
        if(number.length()<3||number.length()>30)throw new Exception("أدخل الرقم التعريفي بشكل صحيح (3 إلى 30 خانة)");
        if(name.length()<3||name.length()>80)throw new Exception("أدخل الاسم الكامل بشكل صحيح");
        SQLiteDatabase d=getWritableDatabase(); Cursor c=d.rawQuery("SELECT id,status,name FROM students WHERE student_no=?",new String[]{number});
        try{if(c.moveToFirst()){if(!clean(c.getString(2)).equalsIgnoreCase(name))throw new Exception("هذا الرقم التعريفي مسجل مسبقاً باسم مختلف. راجع الإدارة.");JSONObject o=new JSONObject();o.put("id",c.getLong(0));o.put("status",c.getString(1));o.put("name",c.getString(2));return o;}}finally{c.close();}
        ContentValues v=new ContentValues();v.put("student_no",number);v.put("name",name);v.put("status","pending");v.put("created_at",now());long id=d.insertOrThrow("students",null,v);
        JSONObject o=new JSONObject();o.put("id",id);o.put("status","pending");o.put("name",name);return o;
    }
    public synchronized JSONObject studentStatus(String number)throws Exception{
        Cursor c=getReadableDatabase().rawQuery("SELECT id,student_no,name,status FROM students WHERE student_no=?",new String[]{clean(number).toUpperCase(Locale.ROOT)});
        try{if(!c.moveToFirst())return new JSONObject().put("status","missing");return new JSONObject().put("id",c.getLong(0)).put("studentNo",c.getString(1)).put("name",c.getString(2)).put("status",c.getString(3));}finally{c.close();}
    }
    public synchronized JSONArray students(String status)throws Exception{
        JSONArray a=new JSONArray();Cursor c=getReadableDatabase().rawQuery("SELECT id,student_no,name,status,created_at FROM students WHERE (?='all' OR status=?) ORDER BY created_at DESC",new String[]{status,status});
        try{while(c.moveToNext())a.put(new JSONObject().put("id",c.getLong(0)).put("studentNo",c.getString(1)).put("name",c.getString(2)).put("status",c.getString(3)).put("createdAt",c.getString(4)));}finally{c.close();}return a;
    }
    public synchronized void approve(long id)throws Exception{ContentValues v=new ContentValues();v.put("status","approved");if(getWritableDatabase().update("students",v,"id=? AND status='pending'",new String[]{String.valueOf(id)})==0)throw new Exception("طلب التسجيل غير موجود أو تمت معالجته");}
    public synchronized void reject(long id){getWritableDatabase().delete("students","id=? AND status='pending'",new String[]{String.valueOf(id)});}
    public synchronized JSONObject newLecture(String title)throws Exception{
        title=clean(title);if(title.isEmpty())title="محاضرة جديدة";SQLiteDatabase d=getWritableDatabase();d.execSQL("UPDATE lectures SET active=0");ContentValues v=new ContentValues();v.put("title",title);v.put("created_at",now());v.put("active",1);long id=d.insertOrThrow("lectures",null,v);return new JSONObject().put("id",id).put("title",title).put("createdAt",now());
    }
    public synchronized JSONObject currentLecture()throws Exception{Cursor c=getReadableDatabase().rawQuery("SELECT id,title,created_at FROM lectures WHERE active=1 ORDER BY id DESC LIMIT 1",null);try{if(!c.moveToFirst())return new JSONObject();return new JSONObject().put("id",c.getLong(0)).put("title",c.getString(1)).put("createdAt",c.getString(2));}finally{c.close();}}
    public synchronized JSONObject markAttendance(long studentId,long lectureId)throws Exception{
        SQLiteDatabase d=getWritableDatabase();Cursor s=d.rawQuery("SELECT name,student_no FROM students WHERE id=? AND status='approved'",new String[]{String.valueOf(studentId)});String name,no;try{if(!s.moveToFirst())throw new Exception("الطالب غير معتمد من الإدارة");name=s.getString(0);no=s.getString(1);}finally{s.close();}
        Cursor l=d.rawQuery("SELECT title FROM lectures WHERE id=? AND active=1",new String[]{String.valueOf(lectureId)});try{if(!l.moveToFirst())throw new Exception("هذه المحاضرة غير مفتوحة حالياً");}finally{l.close();}
        String t=now();ContentValues v=new ContentValues();v.put("lecture_id",lectureId);v.put("student_id",studentId);v.put("scanned_at",t);long id=d.insertWithOnConflict("attendance",null,v,SQLiteDatabase.CONFLICT_IGNORE);if(id==-1)throw new Exception("تم تسجيل حضورك مسبقاً في هذه المحاضرة");return new JSONObject().put("ok",true).put("name",name).put("studentNo",no).put("time",t);
    }
    public synchronized JSONArray attendees(long lectureId)throws Exception{JSONArray a=new JSONArray();Cursor c=getReadableDatabase().rawQuery("SELECT s.student_no,s.name,a.scanned_at FROM attendance a JOIN students s ON s.id=a.student_id WHERE a.lecture_id=? ORDER BY a.scanned_at",new String[]{String.valueOf(lectureId)});try{while(c.moveToNext())a.put(new JSONObject().put("studentNo",c.getString(0)).put("name",c.getString(1)).put("time",c.getString(2)));}finally{c.close();}return a;}
    public synchronized int count(String table,String where){Cursor c=getReadableDatabase().rawQuery("SELECT COUNT(*) FROM "+table+(where==null?"":" WHERE "+where),null);try{c.moveToFirst();return c.getInt(0);}finally{c.close();}}
}
