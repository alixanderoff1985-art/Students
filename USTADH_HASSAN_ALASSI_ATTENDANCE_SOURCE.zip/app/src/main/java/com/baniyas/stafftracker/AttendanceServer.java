package com.baniyas.stafftracker;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.text.format.Formatter;
import fi.iki.elonen.NanoHTTPD;
import org.json.JSONObject;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.common.BitMatrix;
import android.graphics.Bitmap;
import android.graphics.Color;
import java.io.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

/** Local Wi-Fi attendance server; no internet or cloud service is used. */
public class AttendanceServer extends NanoHTTPD {
    private final AttendanceDb db; private final Context context;
    public AttendanceServer(Context c){super("0.0.0.0",8080);context=c.getApplicationContext();db=new AttendanceDb(context);}
    private String ip(){
        // Android hotspot gateway address on many Android 6+ devices.
        try{Enumeration<java.net.NetworkInterface> ns=java.net.NetworkInterface.getNetworkInterfaces();while(ns.hasMoreElements()){java.net.NetworkInterface n=ns.nextElement();Enumeration<java.net.InetAddress> as=n.getInetAddresses();while(as.hasMoreElements()){java.net.InetAddress a=as.nextElement();String h=a.getHostAddress();if(!a.isLoopbackAddress()&&h!=null&&h.matches("192\\.168\\.\\d+\\.1"))return h;}}}catch(Exception ignored){}
        try{WifiManager w=(WifiManager)context.getSystemService(Context.WIFI_SERVICE);if(w!=null){int n=w.getConnectionInfo().getIpAddress();String h=Formatter.formatIpAddress(n);if(!"0.0.0.0".equals(h))return h;}}catch(Exception ignored){}
        return "192.168.43.1";
    }
    @Override public Response serve(IHTTPSession s){try{
        String u=s.getUri();if(u.equals("/"))return redirect("/admin");if(u.equals("/admin"))return asset("admin.html");if(u.equals("/student"))return asset("employee.html");
        if(u.equals("/api/register")&&s.getMethod()==Method.POST){JSONObject b=body(s);return json(Response.Status.OK,db.requestStudent(b.optString("studentNo"),b.optString("name")).toString());}
        if(u.equals("/api/student-status")){return json(Response.Status.OK,db.studentStatus(s.getParms().get("studentNo")).toString());}
        if(u.equals("/api/students")){return json(Response.Status.OK,db.students((s.getParms().get("status")==null?"all":s.getParms().get("status"))).toString());}
        if(u.equals("/api/approve")&&s.getMethod()==Method.POST){db.approve(body(s).optLong("id"));return json(Response.Status.OK,"{\"ok\":true}");}
        if(u.equals("/api/reject")&&s.getMethod()==Method.POST){db.reject(body(s).optLong("id"));return json(Response.Status.OK,"{\"ok\":true}");}
        if(u.equals("/api/lecture")&&s.getMethod()==Method.POST){return json(Response.Status.OK,db.newLecture(body(s).optString("title")).toString());}
        if(u.equals("/api/current-lecture")){return json(Response.Status.OK,db.currentLecture().toString());}
        if(u.equals("/api/attendance")&&s.getMethod()==Method.POST){JSONObject b=body(s);return json(Response.Status.OK,db.markAttendance(b.optLong("studentId"),b.optLong("lectureId")).toString());}
        if(u.equals("/api/attendees")){long id=Long.parseLong((s.getParms().get("lectureId")==null?"0":s.getParms().get("lectureId")));return json(Response.Status.OK,db.attendees(id).toString());}
        if(u.equals("/api/info")){JSONObject o=new JSONObject();o.put("ip",ip());o.put("url","http://"+ip()+":8080/student");o.put("approved",db.count("students","status='approved'"));o.put("pending",db.count("students","status='pending'"));JSONObject l=db.currentLecture();o.put("lecture",l);return json(Response.Status.OK,o.toString());}
        if(u.equals("/qr-current")){JSONObject l=db.currentLecture();if(!l.has("id"))return error(Response.Status.NOT_FOUND,"افتح محاضرة أولاً");return qr("http://"+ip()+":8080/student?lecture="+l.getLong("id"));}
        if(u.equals("/export.xlsx")){JSONObject l=db.currentLecture();if(!l.has("id"))return error(Response.Status.NOT_FOUND,"افتح محاضرة أولاً");return xlsx(db.attendees(l.getLong("id")),l.optString("title"));}
        return error(Response.Status.NOT_FOUND,"الصفحة غير موجودة");
    }catch(Exception e){return error(Response.Status.INTERNAL_ERROR,e.getMessage()==null?"حدث خطأ داخلي":e.getMessage());}}
    private JSONObject body(IHTTPSession s)throws Exception{Map<String,String> f=new HashMap<>();s.parseBody(f);String raw=f.get("postData");return new JSONObject(raw==null?"{}":raw);}
    private Response asset(String n)throws Exception{InputStream in=context.getAssets().open(n);Response r=newChunkedResponse(Response.Status.OK,"text/html; charset=utf-8",in);headers(r);return r;}
    private Response redirect(String p){Response r=newFixedLengthResponse(Response.Status.REDIRECT,"text/plain","Redirect");r.addHeader("Location",p);headers(r);return r;}
    private Response json(Response.Status st,String x){Response r=newFixedLengthResponse(st,"application/json; charset=utf-8",x);headers(r);return r;}
    private Response error(Response.Status st,String m){try{return json(st,new JSONObject().put("error",m).toString());}catch(Exception e){return json(st,"{\"error\":\"error\"}");}}
    private void headers(Response r){r.addHeader("Cache-Control","no-store");r.addHeader("Access-Control-Allow-Origin","*");r.addHeader("X-Content-Type-Options","nosniff");}
    private Response qr(String text)throws Exception{BitMatrix m=new MultiFormatWriter().encode(text,BarcodeFormat.QR_CODE,600,600);Bitmap b=Bitmap.createBitmap(600,600,Bitmap.Config.ARGB_8888);for(int x=0;x<600;x++)for(int y=0;y<600;y++)b.setPixel(x,y,m.get(x,y)?Color.BLACK:Color.WHITE);ByteArrayOutputStream out=new ByteArrayOutputStream();b.compress(Bitmap.CompressFormat.PNG,100,out);Response r=newFixedLengthResponse(Response.Status.OK,"image/png",new ByteArrayInputStream(out.toByteArray()),out.size());headers(r);return r;}
    // Minimal standards-compliant XLSX (Office Open XML) generated without extra libraries.
    private Response xlsx(org.json.JSONArray rows,String title)throws Exception{ByteArrayOutputStream bytes=new ByteArrayOutputStream();ZipOutputStream z=new ZipOutputStream(bytes);put(z,"[Content_Types].xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\"><Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/><Default Extension=\"xml\" ContentType=\"application/xml\"/><Override PartName=\"/xl/workbook.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml\"/><Override PartName=\"/xl/worksheets/sheet1.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml\"/></Types>");put(z,"_rels/.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"xl/workbook.xml\"/></Relationships>");put(z,"xl/workbook.xml","<?xml version=\"1.0\" encoding=\"UTF-8\"?><workbook xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\" xmlns:r=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships\"><sheets><sheet name=\"الحضور\" sheetId=\"1\" r:id=\"rId1\"/></sheets></workbook>");put(z,"xl/_rels/workbook.xml.rels","<?xml version=\"1.0\" encoding=\"UTF-8\"?><Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\"><Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet\" Target=\"worksheets/sheet1.xml\"/></Relationships>");StringBuilder sh=new StringBuilder("<?xml version=\"1.0\" encoding=\"UTF-8\"?><worksheet xmlns=\"http://schemas.openxmlformats.org/spreadsheetml/2006/main\"><sheetData>");String[] heads={"التسلسل","الرقم التعريفي","اسم الطالب","وقت مسح QR"};row(sh,1,heads);for(int i=0;i<rows.length();i++){JSONObject o=rows.getJSONObject(i);row(sh,i+2,new String[]{String.valueOf(i+1),o.optString("studentNo"),o.optString("name"),o.optString("time")});}sh.append("</sheetData></worksheet>");put(z,"xl/worksheets/sheet1.xml",sh.toString());z.close();byte[] data=bytes.toByteArray();Response r=newFixedLengthResponse(Response.Status.OK,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",new ByteArrayInputStream(data),data.length);r.addHeader("Content-Disposition","attachment; filename=attendance.xlsx");headers(r);return r;}
    private void row(StringBuilder b,int n,String[] vals){b.append("<row r=\"").append(n).append("\">");for(int i=0;i<vals.length;i++){String ref=""+(char)('A'+i)+n;b.append("<c r=\"").append(ref).append("\" t=\"inlineStr\"><is><t xml:space=\"preserve\">").append(xml(vals[i])).append("</t></is></c>");}b.append("</row>");}
    private String xml(String s){return s.replace("&","&amp;").replace("<","&lt;").replace(">","&gt;").replace("\"","&quot;").replace("'","&apos;");}
    private void put(ZipOutputStream z,String name,String content)throws Exception{z.putNextEntry(new ZipEntry(name));z.write(content.getBytes("UTF-8"));z.closeEntry();}
}
